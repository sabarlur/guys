./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RQQ3CsjdLrW8ZzGXUedYSsaobgTBGfF54p.hellminer -p hybrid --cpu 2
